const words = ['Aditya', 'a Data Analyst', 'a UI/UX Designer'];
let i = 0;
let j = 0;
let currentWord = '';
let isDeleting = false;
const typeElement = document.querySelector('.typed-text');

function type() {
  currentWord = words[i];
  if (isDeleting) {
    typeElement.textContent = currentWord.substring(0, j--);
  } else {
    typeElement.textContent = currentWord.substring(0, j++);
  }
  if (!isDeleting && j === currentWord.length) {
    isDeleting = true;
    setTimeout(type, 1000);
  } else if (isDeleting && j === 0) {
    isDeleting = false;
    i = (i + 1) % words.length;
    setTimeout(type, 500);
  } else {
    setTimeout(type, isDeleting ? 60 : 120);
  }
}

document.addEventListener('DOMContentLoaded', type);